package com.ucloud.common.multitenancy;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.ucloud.json.JSONObject;

/**
 * Multitenancy configuration.
 * For simple key-value setting, map would be made.
 * For complex object or array setting, external handler would be needed.
 * 
 * @author yusbha
 * @version 0.3
 * @since 20151030
 * @see MultitenancyConstants
 *
 */
public class MultitenancyConfiguration {
    private Map<Tuple3, Object> settings = new HashMap<Tuple3, Object>();
    private Map<Tuple2, String> policies = new HashMap<Tuple2, String>();
    
	/**
	 * @param strMultitenancyPolicies should not be null.
	 * @param strServiceMultitenancyPolicies should not be null.
	 * @param handler for complext setting
	 */
	public MultitenancyConfiguration(String strMultitenancyPolicies, String strServiceMultitenancyPolicies, MultitenancyConfigurationHandler handler) {
		Map<String, Map<String, Map<String, Object>>> groupPolicySettingMap = new HashMap<String, Map<String, Map<String, Object>>>();
		
		if(strMultitenancyPolicies != null) {
			JSONObject multitenancyPolicies = new JSONObject(strMultitenancyPolicies);
			Iterator<String> multitenancyPolicyNames = multitenancyPolicies.keys();
			while(multitenancyPolicyNames.hasNext()) {
				String groupName = multitenancyPolicyNames.next();
				JSONObject policies = multitenancyPolicies.getJSONObject(groupName);
        		
				Map<String, Map<String, Object>> policySettingMap = groupPolicySettingMap.get(groupName);
				if(policySettingMap == null) {
					policySettingMap = new HashMap<String, Map<String, Object>>();
					groupPolicySettingMap.put(groupName, policySettingMap);
				}
        		
				Iterator<String> policyNames = policies.keys();
				while(policyNames.hasNext()) {
					String policyName = policyNames.next();
					if(handler != null && handler.responsibleFor(groupName)) {
						handler.handle(groupName, policyName, policies.get(policyName));
					} else {
						JSONObject policy = policies.getJSONObject(policyName);
						
						Map<String, Object> settingMap = policySettingMap.get(policyName);
						if(settingMap == null) {
							settingMap = new HashMap<String, Object>();
							policySettingMap.put(policyName, settingMap);
						}
						
						Iterator<String> settingNames = policy.keys();
						while(settingNames.hasNext()) {
							String settingName = settingNames.next();
							Object setting = policy.get(settingName);
							
							settingMap.put(settingName, setting);
       				
							if(MultitenancyConstants.DEFAULT.equals(policyName)) {
								Tuple3 tuple3 = new Tuple3(groupName, MultitenancyConstants.DEFAULT, settingName);
        						this.settings.put(tuple3, setting);
        					}
						}
					}
        		}
        	}
        }
		
        if(strServiceMultitenancyPolicies != null) {
        	JSONObject serviceMultitenancyPolicies = new JSONObject(strServiceMultitenancyPolicies);
        	Iterator<String> serviceMultitenancyPolicyNames = serviceMultitenancyPolicies.keys();
        	while(serviceMultitenancyPolicyNames.hasNext()) {
        		String serviceName = serviceMultitenancyPolicyNames.next();
        		JSONObject multitenancyPolicies = serviceMultitenancyPolicies.getJSONObject(serviceName);
        		
        		Iterator<String> groupNames = multitenancyPolicies.keys();
        		while(groupNames.hasNext()) {
        			String groupName = groupNames.next();
        			String policyName = multitenancyPolicies.getString(groupName);
        			
       				if(handler != null && handler.responsibleFor(groupName)) {
       					Tuple2 tuple2 = new Tuple2(groupName, serviceName);
       					this.policies.put(tuple2, policyName);
       				} else {
       					Map<String, Map<String, Object>> policySettingMap = groupPolicySettingMap.get(groupName);
        				if(policySettingMap != null) {
        					Map<String, Object> settingMap = policySettingMap.get(policyName);
        					if(settingMap != null) {
        						for(Map.Entry<String, Object> entry : settingMap.entrySet()) {
        							String settingName = entry.getKey();
        							Object setting = entry.getValue();
        						
        							Tuple3 tuple3 = new Tuple3(groupName, serviceName, settingName);
        							this.settings.put(tuple3, setting);
        						}
        					}
        				}
        			}
        		}
        	}
        }
	}
	
	/**
	 * For complex setting, only policy name would be given from configuration.
	 * Settings should be managed by external manager created by handler.
	 * 
	 * @param groupName
	 * @param serviceName
	 * @return policyName
	 */
	public String getPolicy(String groupName, String serviceName) {
		Tuple2 tuple2 = new Tuple2(groupName, serviceName);
		String policyName = this.policies.get(tuple2);
		
		if(policyName == null) {
			policyName = MultitenancyConstants.DEFAULT;
		}
		
		return policyName;
	}
	
	/**
	 * For simple setting, setting would be given from configuration.
	 * Setting could be String, Long, Integer or Boolean.
	 * 
	 * @param groupName
	 * @param serviceName
	 * @param settingName
	 * @return setting
	 */
	public Object get(String groupName, String serviceName, String settingName) {
		Tuple3 tuple3 = new Tuple3(groupName, serviceName, settingName);
		Object setting = this.settings.get(tuple3);
		
		if(setting == null) {
			tuple3 = new Tuple3(groupName, MultitenancyConstants.DEFAULT, settingName);
			setting = this.settings.get(tuple3);
		}
		
		return setting;
	}
	
	private class Tuple3 {
		String group;
		String service;
		String setting;
		
		public Tuple3(String group, String service, String setting) {
			this.group = group;
			this.service = service;
			this.setting = setting;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((group == null) ? 0 : group.hashCode());
			result = prime * result + ((service == null) ? 0 : service.hashCode());
			result = prime * result + ((setting == null) ? 0 : setting.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Tuple3 other = (Tuple3) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (group == null) {
				if (other.group != null)
					return false;
			} else if (!group.equals(other.group))
				return false;
			if (service == null) {
				if (other.service != null)
					return false;
			} else if (!service.equals(other.service))
				return false;
			if (setting == null) {
				if (other.setting != null)
					return false;
			} else if (!setting.equals(other.setting))
				return false;
			return true;
		}

		private MultitenancyConfiguration getOuterType() {
			return MultitenancyConfiguration.this;
		}
	}
	
	private class Tuple2 {
		String group;
		String service;
		
		public Tuple2(String group, String service) {
			this.group = group;
			this.service = service;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((group == null) ? 0 : group.hashCode());
			result = prime * result + ((service == null) ? 0 : service.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Tuple2 other = (Tuple2) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (group == null) {
				if (other.group != null)
					return false;
			} else if (!group.equals(other.group))
				return false;
			if (service == null) {
				if (other.service != null)
					return false;
			} else if (!service.equals(other.service))
				return false;
			return true;
		}

		private MultitenancyConfiguration getOuterType() {
			return MultitenancyConfiguration.this;
		}
	}
}
