package com.ucloud.common.multitenancy;

/**
 * There should be two configurations for multitenancy.
 * 
 * One for Multitenancy Policy:
 * {
 *   "MQ_publish" : {
 *     "default" : {
 *       "key_with_service" : false
 *     },
 *     "service_based" : {
 *       "key_with_service" : true
 *     }
 *   },
 *   "PUSH_publish" : {
 *     "default" : {
 *       "publish" : true
 *     },
 *     "no_publish" : {
 *       "publish" : false
 *     }
 *   },
 *   "MogileFS" : {
 *     "new_machine" : [
 *       "ss00",
 *       ...
 *     ],
 *     ...
 *   }
 * }
 * The other for Service Multitenancy Policy:
 * {
 *   "ucloud" : {
 *   },
 *   "home" : {
 *     "MQ_publish" : "service_based",
 *     "PUSH_publish" : "no_publish",
 *     "MogileFS" : "new_machine"
 *   }
 * }
 * 
 * Policy Group Name and Setting Name should be declared here.
 * Service Name and Policy Name be declared freely.
 * 
 * @author yusbha
 * @version 0.3
 * @since 20151029
 *
 */
public interface MultitenancyConstants {
	public static final String CONF_MULTITENANCY_POLICIES = "multitenancy_policies";
	
	public static final String DEFAULT = "default";
	
	public static final String MQ_PUBLISH = "MQ_publish"; // When published to MQ.
	public static final String KEY_WITH_SERVICE = "key_with_service"; // If true, MQ topic would contain the service type.
	
	public static final String PUSH_PUBLISH = "PUSH_publish"; // When published to PUSH.
	public static final String PUBLISH = "publish"; // If true, PUSH message would be sent.
	
	public static final String MOGILE_FS = "MogileFS"; // Information to select MogileFS.
	
	public static final String CONF_SERVICE_MULTITENANCY_POLICIES = "service_multitenancy_policies";
}
