package com.ucloud.common.multitenancy;

/**
 * When multitenancy configuration be initialized, some configurations would contain complex settings. (object or array)
 * For those, other manager object would be necessary instead of storing simple key-value settings in configuration object.
 * 
 * @author yusbha
 * @version 0.3
 * @since 20151029
 */
public interface MultitenancyConfigurationHandler {
	
	/**
	 * To determine whether handler would handle the settings under given group.
	 * Only the groupName with true response would be given.
	 * 
	 * @param groupName 
	 * @return
	 */
	public boolean responsibleFor(String groupName);
	
	/**
	 * Maybe, to construct manager object about settings.
	 * 
	 * @param groupName
	 * @param policyName
	 * @param setting
	 */
	public void handle(String groupName, String policyName, Object setting);
}
