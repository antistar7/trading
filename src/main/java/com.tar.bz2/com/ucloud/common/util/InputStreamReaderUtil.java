package com.ucloud.common.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author : Hur Yongsoo
 * @version 0.1
 * @since 12. 1. 19
 */
@SuppressWarnings({"UtilityClass"})
public class InputStreamReaderUtil {
    private static final int MAX_BUFFER_SIZE = 4096;

    private InputStreamReaderUtil() {

    }

    /**
     * Read whole data from inputstream. It cannot be used to streaming.
     * @param is InputStream to read
     * @return byte[] from inputStream
     * @throws java.io.IOException if InputStream cannot read
     */
    public static byte[] readInputStream(InputStream is) throws IOException {
        byte[] buffer = new byte[MAX_BUFFER_SIZE];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        int readSize;
        while((readSize = is.read(buffer))!= -1) {
            baos.write(buffer, 0, readSize);
        }

        return baos.toByteArray();
    }


}
