package com.ucloud.common.util;

import java.nio.ByteBuffer;
import java.util.UUID;

/**
 * For building byte array (16 bytes) or hex string (32 characters).
 * 
 * @author yusbha
 * @version 0.3
 * @since 20151103
 *
 */
public class HexBuilder {
	private UUID uuid;
	private byte[] bytes;
	private String string;
	
	/**
	 * To construct the basis of byte array.
	 */
	public HexBuilder() {
		this.uuid = UUID.randomUUID();
	}
	
	/**
	 * For converting hex string to byte array.
	 * 
	 * @param string
	 */
	public HexBuilder(String string) {
		this.string = string;
		if(this.string == null || this.string.length() == 0) throw new IllegalArgumentException();
		this.bytes = new byte[this.string.length() / 2];
		for(int index = 0;index < this.bytes.length;index++)
			this.bytes[index] = (byte) Integer.parseInt(string.substring(2 * index, 2 * index + 2), 16);
	}
    
	/**
	 * @return byte array (16 bytes)
	 */
	public byte[] getBytes() {
		if(this.bytes == null) {
			synchronized(this.uuid) {
				if(this.bytes == null) {
					ByteBuffer buffer = ByteBuffer.wrap(new byte[16]);
					buffer.putLong(this.uuid.getMostSignificantBits());
					buffer.putLong(this.uuid.getLeastSignificantBits());
					this.bytes = buffer.array();
				}
			}
		}
		
		return this.bytes;
	}
	
	/**
	 * @return hex string (32 characters)
	 */
	@Override
	public String toString() {
		if(this.string == null) {
			synchronized(this.string) {
				if(this.string == null) {
					String source = this.uuid.toString();
					this.string = new StringBuilder()
						.append(source.substring(0, 8))
						.append(source.substring(9, 13))
						.append(source.substring(14, 18))
						.append(source.substring(19, 23))
						.append(source.substring(24, 36))
						.toString();
					
				}
			}
		}
		
		return this.string;
	}
}
