package com.ucloud.common.util;

/**
 * 문자열 처리 혹은 다른 객체 등 처리에 사용하는 간단한 유틸리티 로직을 담은 클래스. 
 * @author hayarobi
 *
 */
public class StringUtil {

	public static String null2Empty(String src) {
		if( src == null )
			return "";
		return src;
	}
}
