package com.ucloud.common.util;

/**
 * 숫자형 래퍼 클래스와 primitive타입 간의 처리에 사용하는 간단한 유틸리티 로직을 담은 클래스. 
 * @author hayarobi
 *
 */
public class NumericUtil {
	/**
	 * 박싱된 Integer객체값의 primitive형 값을 반환한다. 객체가 null이면 설정한 nullValue값을 반환한다.
	 * @param src
	 * @param nullValue src가 null일 때 반환하는 값.
	 * @return
	 */
	public static int null2int(Integer src, int nullValue) {
		if( src == null )
			return nullValue;
		return src;		
	}

	/**
	 * 객체가 null이면 0을 반환한다.
	 * @param src
	 * @return
	 */
	public static int null2Zero(Integer src) {
		return null2int(src, 0);
	}

	
	/**
	 * 	박싱된 Long 객체값의 primitive형 값을 반환한다. 객체가 null이면 설정한 nullValue값을 반환한다.
	 * @param src
	 * @param nullValue
	 * @return
	 */
	public static long null2long(Long src, long nullValue) {
		if( src == null )
			return nullValue;
		return src;		
	}

	public static long null2ZeroL(Long src) {
		return null2long(src, 0L);
	}

}
