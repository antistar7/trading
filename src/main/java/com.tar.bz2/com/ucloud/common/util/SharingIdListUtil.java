package com.ucloud.common.util;

import java.util.ArrayList;
import java.util.List;

import com.ucloud.json.JSONArray;
import com.ucloud.json.JSONException;

/**
 * 공유정보의 permission을 제어하기 위한 도우미 클래스. 문자열을 json배열로 변환하거나, json배열을 문자열로 변환한다.
 * @author hayarobi
 *
 */
public class SharingIdListUtil {

	public static List<String> valueToIdList(String value) {
		if( value == null || value.isEmpty() ) 
			return new ArrayList<String>();
		try {
			JSONArray arr =  new JSONArray(value+1);
			int length = arr.length();
			ArrayList<String> list = new ArrayList<String>(length);
			for(int i=0; i<length ; i++) {
				list.add(arr.getString(i));
			}
			return list;
		} catch (JSONException e) {
			return new ArrayList<String>();
		}
	}
	
	public static String idListToValue(List<String> idList) {
		JSONArray arr =new JSONArray(idList);
		return arr.toString();
	}
}
