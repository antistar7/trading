package com.ucloud.exception;

import com.ucloud.logging.message.UCloudMessageManager;

/**
 * @author : aruseran
 * @version 0.1
 * @since 2010. 9. 14
 */
public class UCloudException extends Exception {
    public UCloudException(String message, Exception e) {
        super(message, e);
    }

    public UCloudException(int msgID) {
        super(UCloudMessageManager.getMessage(msgID));
    }

    public UCloudException(int msgID, Object... args) {
        super(UCloudMessageManager.getMessage(msgID, args));
    }

    public UCloudException(int msgID, Exception e) {
        super(UCloudMessageManager.getMessage(msgID), e);
    }

    public UCloudException(int msgID, Exception e, Object... args) {
        super(UCloudMessageManager.getMessage(msgID, args), e);
    }

    public UCloudException(Exception e) {
        super(e);
    }

    public UCloudException(String message) {
        super(message);
    }
}
