package com.ucloud.exception;

/**
 * @author : aruseran
 * @version 0.1
 * @since 2010. 9. 14
 */
public class UCloudRuntimeException extends RuntimeException {
    public UCloudRuntimeException(String message, Throwable e) {
        super(message,e);
    }
    public UCloudRuntimeException(String message) {
        super(message);
    }

    public UCloudRuntimeException(Throwable e) {
        super(e);
    }
}
