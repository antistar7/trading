package com.ucloud.logging.logger;

import com.ucloud.logging.message.UCloudMessageManager;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

/**
 * @author : aruseran
 * @version 0.1
 * @since 2010. 12. 7
 */
public class UCloudLogger {
    private UCloudLogger parent;

    private UCloudLevel level = UCloudLevel.INFO;
    private Logger logger;
    private String loggerName;
    private String logPath = ".";
    private String logCycle = "daily";

    private Map<String, UCloudHandler> handlerMap = new HashMap<String, UCloudHandler>();

    UCloudLogger(UCloudLogger parent, String loggerName) {
        this.parent = parent;
        this.level = parent.getLevel();
        this.logCycle = parent.getLogCycle();
        this.loggerName = loggerName;
        logger = Logger.getLogger(loggerName);
        logger.setParent(parent.logger);
    }

    UCloudLogger(String loggerName) {
        // For Root Logger
        this.loggerName = loggerName;
        this.logCycle = "daily";
        this.level = UCloudLevel.INFO;
        this.logPath = ".";

        logger = Logger.getLogger(loggerName);
    }

    public static UCloudLogger getLogger(String clazzName) {
        return UCloudLoggerManager.getInstance().getLogger(clazzName);
    }

    public static UCloudLogger getLogger(Class clazz) {
        return UCloudLoggerManager.getInstance().getLogger(clazz.getCanonicalName());
    }

    public UCloudLogger getParent() {
        return parent;
    }

    public String getLoggerName() {
        return loggerName;
    }

    public UCloudLevel getLevel() {
        return level;
    }

    public String getLogLevel() {
        return level.getName();
    }

    public synchronized void setLevel(UCloudLevel level) {
		if (level == null) {
			setLevel(UCloudLevel.INFO);
			return;
		}
		this.level = level;
		logger.setLevel(level.getLevel());
		Handler[] handlers = logger.getHandlers();
		for (Handler handler : handlers) {
			handler.setLevel(level.getLevel());
		}
	}

    public synchronized void setLevel(String level) {
		if (level == null) {
			setLevel(UCloudLevel.INFO);
			return;
		}
		UCloudLevel ucloudLevel = UCloudLevel.getLevel(level);
		if (ucloudLevel == null) {
			setLevel(UCloudLevel.INFO);
        }
		else {
			setLevel(ucloudLevel);
        }
	}

	public boolean isDebugEnabled() {
        return level.intValue() < UCloudLevel.DEBUG.intValue();
	}

	public boolean isLoggable(UCloudLevel ucloudLevel) {
		return level.intValue() <= ucloudLevel.intValue();
	}

    public void log(Object messageID) {
		if (messageID == null) {
			log(UCloudLevel.INFO, "");
			return;
		}
		UCloudLevel level = UCloudMessageManager.getLevel(messageID);
		log(level, messageID);
	}

	public void log(UCloudLevel ucloudLevel, Object messageID) {
		if(!isLoggable(ucloudLevel))
			return;
		if (messageID == null) {
			doLog(null, ucloudLevel, null);
			return;
		}
		if (!UCloudMessageManager.isInitialized()) {
			doLog(null,ucloudLevel, messageID);
			return;
		}

		String message = UCloudMessageManager.getMessage(messageID);
		doLog(null, ucloudLevel, message);
	}

	public void log(UCloudLevel ucloudLevel, Exception e) {
		if( !isLoggable(ucloudLevel) )
			return;
		doLog(e, ucloudLevel, e.getMessage());
	}

	public void log(Object messageID, Throwable e) {
		UCloudLevel level = UCloudMessageManager.getLevel(messageID);
		log(level, messageID, e);
	}

	public void log(UCloudLevel ucloudLevel, Object messageID, Throwable e) {
		if( !isLoggable(ucloudLevel) ) {
			return;
        }
		String message = UCloudMessageManager.getMessage(messageID);
		doLog(e, ucloudLevel, message);
	}

	public void log(Object messageID, Object... args) {
		UCloudLevel level = UCloudMessageManager.getLevel(messageID);
		log(level, messageID, args);
	}

	public void log(UCloudLevel ucloudLevel, Object messageID, Object... args) {
		if( !isLoggable(ucloudLevel) )
			return;
		if (!UCloudMessageManager.isInitialized()) {
			doLog(null,ucloudLevel, messageID);
			return;
		}
		if (isLoggable(ucloudLevel)) {
			String message = UCloudMessageManager.getMessage(messageID, args);
			doLog(null, ucloudLevel, message);
		}
	}

	public void log(Object messageID, Throwable e, Object... args) {
		if (messageID == null) {
			log(UCloudLevel.INFO, "", e, args);
			return;
		}
		UCloudLevel level = UCloudMessageManager.getLevel(messageID);
		log(level, messageID, e, args);
	}

	public void log(UCloudLevel ucloudLevel, Object messageID, Throwable e, Object... args) {
		if( !isLoggable(ucloudLevel) ) {
			return;
        }
		String message = UCloudMessageManager.getMessage(messageID, args);
		doLog(e, ucloudLevel, message);
	}

    public void info(Object messageID) {
        log(UCloudLevel.INFO, messageID);
    }

    public void info(Object messageID, Throwable e) {
		log(UCloudLevel.INFO, messageID, e);
	}

    public void info(Object messageID, Throwable e, Object... args) {
		log(UCloudLevel.INFO, messageID, e, args);
	}

    public void warn(Object messageID) {
		log(UCloudLevel.WARN, messageID);
	}

	public void warn(Object messageID, Throwable e) {
		log(UCloudLevel.WARN, messageID, e);
	}

	public void warn(Object messageID, Throwable e, Object... args) {
		log(UCloudLevel.WARN, messageID, e, args);
	}

	public void fatal(Object messageID) {
		log(UCloudLevel.FATAL, messageID);
	}

	public void fatal(Object messageID, Throwable e) {
		log(UCloudLevel.FATAL, messageID, e);
	}

	public void fatal(Object messageID, Throwable e, Object... args) {
		log(UCloudLevel.FATAL, messageID, e, args);
	}

	public void debug(Object messageID) {
		log(UCloudLevel.DEBUG, messageID);
	}

	public void debug(Object messageID, Throwable e) {
		log(UCloudLevel.DEBUG, messageID, e);
	}

	public void debug(Object messageID, Throwable e, Object... args) {
		log(UCloudLevel.DEBUG, messageID, e, args);
	}

	public void error(Object messageID) {
		log(UCloudLevel.ERROR, messageID);
	}

	public void error(Object messageID, Throwable e) {
		log(UCloudLevel.ERROR, messageID, e);
	}

	public void error(Object messageID, Throwable e, Object... args) {
		log(UCloudLevel.ERROR, messageID, e, args);
	}

	public void trace(Object messageID) {
		log(UCloudLevel.TRACE, messageID);
	}

	public void trace(Object messageID, Throwable e) {
		log(UCloudLevel.TRACE, messageID, e);
	}

	public void trace(Object messageID, Throwable e, Object... args) {
		log(UCloudLevel.TRACE, messageID, e, args);
	}

    void addHandler(String handlerName, UCloudHandler handler) {
        handlerMap.put(handlerName, handler);
        logger.addHandler((Handler) handler);
        logger.setUseParentHandlers(false);
    }

    void removeHandler(String handlerName) {
        Handler handler = (Handler) handlerMap.remove(handlerName);
        if(handlerMap.size() == 0) {
            logger.setUseParentHandlers(true);
        }
        logger.removeHandler(handler);
    }

    UCloudHandler getHandler(String handlerName) {
        return handlerMap.get(handlerName);
    }

    public String getLogPath() {
        return logPath;
    }

    public String getLogCycle() {
        return logCycle;
    }

    private void doLog(Throwable t, UCloudLevel ucLevel, Object msg) {
		// millis and thread are filled by the constructor
        String message;
        if(msg == null) {
            message = "";
        } else {
            message = msg.toString();
        }
		LogRecord record = new LogRecord(ucLevel.getLevel(), message);
		record.setLoggerName(loggerName);
        record.setSourceClassName(loggerName);
		record.setThrown(t);
		logger.log(record);
	}
}
