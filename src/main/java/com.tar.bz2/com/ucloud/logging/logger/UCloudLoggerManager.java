package com.ucloud.logging.logger;

import com.ucloud.json.JSONArray;
import com.ucloud.json.JSONObject;
import com.ucloud.json.XML;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * @author : aruseran
 * @version 0.1
 * @since 2010. 12. 7
 */
public class UCloudLoggerManager {
    public static final String DEFAULT_LOG_FILE_NAME = "ucloud.out";
    private static final String LOGGER_NAME_SEPARATOR = ".";

    private static final String LOGGER_SETTING_FILE_KEY = "com.ucloud.logging.setting";

    private static final String ROOT_LOGGER_NAME = "com.ucloud";
    private static final String TX_LOGGER_NAME = "mstf.ucloud.txlogging";

    private static final String FILE_HANDLER_NAME = "file-handler";
    private static final String CONSOLE_HANDLER_NAME = "console-handler";
    private static final String TX_HANDLER_NAME = "tx-handler";

    private static final String DEFAULT_TX_LOG_FILE_NAME = "tx.log";
    private static final String DEFAULT_LOG_DIR = ".";
    private static final String DEFAULT_LOG_CYCLE = "daily";

    private static final String LOGGING_ROOT_ELEMENT_NAME = "ucloud-logging";
    private static final String SYSTEM_LOGGER_ROOT_ELEMENT = "system-logger";
    private static final String UCLOUD_LOGGER_ROOT_ELEMENT = "ucloud-logger";
    private static final String TX_LOGGER_ELEMENT_NAME = "tx-logger";

    private static final String LOG_PATH_ELEMENT_NAME = "log-path";
    private static final String LOG_LEVEL_ELEMENT_NAME = "log-level";
    private static final String LOG_ROLLING_ELEMENT_NAME = "rolling";
    private static final String LOGGER_NAME_ELEMENT_NAME = "logger-name";

    private static UCloudLoggerManager instance;
    private Map<String, UCloudLogger> loggerMap = new HashMap<String, UCloudLogger>();

    private static UCloudLogFileFormatter logFormatter = new UCloudLogFileFormatter();
    private static UCloudLogTxFileFormatter txFileFormatter = new UCloudLogTxFileFormatter();
    private static UCloudLogConsoleFormatter consoleFormatter = new UCloudLogConsoleFormatter();

    private UCloudLogger rootLogger;
    private UCloudLogger txLogger;


    public static UCloudLoggerManager getInstance() {
        if(instance == null) {
            instance = new UCloudLoggerManager();
        }
        return instance;
    }

    private UCloudLoggerManager() {
        rootLogger = new UCloudLogger(ROOT_LOGGER_NAME);
        txLogger = new UCloudLogger(rootLogger, TX_LOGGER_NAME);
        loggerMap.put(rootLogger.getLoggerName(), rootLogger);
        loggerMap.put(txLogger.getLoggerName(), txLogger);

        //todo 단계별로 여러 곳에서 설정을 loading할 수 있도록 해야함.
        String settingXMLPath = System.getProperty(LOGGER_SETTING_FILE_KEY);
        BufferedReader br = null;
        if(settingXMLPath != null) {
            try {
                br = new BufferedReader(new InputStreamReader(new FileInputStream(new File(settingXMLPath))));
                StringBuilder buffer = new StringBuilder();
                String line;
                while( (line = br.readLine() ) != null) {
                    buffer.append(line);
                }

                reloadConfiguration(buffer.toString());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if(br != null) {
                    try {
                        br.close();
                    } catch (IOException e) {
                        System.err.print("Cannot close setting file ");
                    }
                }
            }
        } else {
            loadDefaultSetting();
        }
    }

    private void loadDefaultSetting() {
        UCloudDailyRollingLogFileHandler fileHandler = new UCloudDailyRollingLogFileHandler(DEFAULT_LOG_CYCLE, DEFAULT_LOG_DIR + File.separator + DEFAULT_LOG_FILE_NAME);
        //UCloudConsoleHandler consoleHandler = new UCloudConsoleHandler();
        fileHandler.setFormatter(logFormatter);
        //consoleHandler.setFormatter(consoleFormatter);
        rootLogger.addHandler(FILE_HANDLER_NAME, fileHandler);
        //rootLogger.addHandler(CONSOLE_HANDLER_NAME, consoleHandler);

        UCloudDailyRollingLogFileHandler txLogHandler = new UCloudDailyRollingLogFileHandler(DEFAULT_LOG_CYCLE, DEFAULT_LOG_DIR + File.separator + DEFAULT_TX_LOG_FILE_NAME);
        txLogHandler.setFormatter(txFileFormatter);
        txLogger.addHandler(TX_HANDLER_NAME, txLogHandler);
    }

    public void reloadConfiguration(String xml) {
        JSONObject setting = XML.toJSONObject(xml).getJSONObject(LOGGING_ROOT_ELEMENT_NAME);
        reloadConfiguration(setting);
    }

    public void reloadConfiguration(JSONObject setting) {
        JSONObject txLoggerSetting = setting.getJSONObject(TX_LOGGER_ELEMENT_NAME);
        if(txLoggerSetting != null) {
            String txLogPath = txLoggerSetting.getString(LOG_PATH_ELEMENT_NAME) == null?DEFAULT_LOG_DIR + File.separator + DEFAULT_TX_LOG_FILE_NAME:txLoggerSetting.getString(LOG_PATH_ELEMENT_NAME);
            String cycle = txLoggerSetting.getString(LOG_ROLLING_ELEMENT_NAME) == null?DEFAULT_LOG_CYCLE:txLoggerSetting.getString(LOG_ROLLING_ELEMENT_NAME);

            UCloudDailyRollingLogFileHandler handler = new UCloudDailyRollingLogFileHandler(cycle, txLogPath);
            handler.setFormatter(txFileFormatter);
            txLogger.removeHandler(TX_HANDLER_NAME);
            txLogger.addHandler(TX_HANDLER_NAME, handler);
        }

        JSONObject systemLoggerSetting = setting.getJSONObject(SYSTEM_LOGGER_ROOT_ELEMENT);
        JSONArray loggerArray = systemLoggerSetting.getJSONArray(UCLOUD_LOGGER_ROOT_ELEMENT);
        int loggerNum = loggerArray.length();
        for(int i = 0; i < loggerNum; i++) {
            JSONObject loggerSetting = loggerArray.getJSONObject(i);
            String loggerName = loggerSetting.getString(LOGGER_NAME_ELEMENT_NAME);
            if(loggerName == null) {
                continue;
            }
            UCloudLogger logger = getLogger(loggerName);
            String logPath = loggerSetting.getString(LOG_PATH_ELEMENT_NAME) == null? logger.getLogPath():loggerSetting.getString(LOG_PATH_ELEMENT_NAME);
            String cycle = loggerSetting.getString(LOG_ROLLING_ELEMENT_NAME) == null?logger.getLogCycle():loggerSetting.getString(LOG_ROLLING_ELEMENT_NAME);
            String level = loggerSetting.getString(LOG_LEVEL_ELEMENT_NAME) == null?logger.getLevel().getName():loggerSetting.getString(LOG_LEVEL_ELEMENT_NAME);
            UCloudDailyRollingLogFileHandler handler = new UCloudDailyRollingLogFileHandler(cycle, logPath);
            handler.setFormatter(logFormatter);
            logger.removeHandler(FILE_HANDLER_NAME);
            logger.addHandler(FILE_HANDLER_NAME, handler);
            logger.setLevel(level);
        }

    }

    public static UCloudLogger getTxLogger() {
        return getInstance().txLogger;
    }

    public synchronized UCloudLogger getLogger(String loggerName) {
        UCloudLogger logger = loggerMap.get(loggerName);
        if(logger == null) {
            logger = createLogger(loggerName);
            loggerMap.put(loggerName, logger);
        }
        return logger;
    }

    private UCloudLogger createLogger(String loggerName) {
        int parentLoggerNameIndex = loggerName.lastIndexOf(LOGGER_NAME_SEPARATOR);
        if(parentLoggerNameIndex == -1) {
            UCloudLogger logger = new UCloudLogger(rootLogger, loggerName);
            loggerMap.put(loggerName, logger);
            return logger;
        } else {
            String parentLoggerName;
            parentLoggerName = loggerName.substring(0, parentLoggerNameIndex);
            UCloudLogger parentLogger;
            parentLogger = getLogger(parentLoggerName);
            UCloudLogger logger = new UCloudLogger(parentLogger, loggerName);
            loggerMap.put(loggerName, logger);
            return logger;
        }

    }
}
