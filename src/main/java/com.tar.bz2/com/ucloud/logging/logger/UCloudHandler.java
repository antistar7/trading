package com.ucloud.logging.logger;

/**
 * @author : syfer
 * @version 0.1
 * @since 12. 6. 14.
 */
public interface UCloudHandler {
}
