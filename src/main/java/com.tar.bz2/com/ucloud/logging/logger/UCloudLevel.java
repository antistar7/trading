package com.ucloud.logging.logger;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

public class UCloudLevel {
	public static final UCloudLevel ALL = new UCloudLevel(Level.ALL);
    public static final UCloudLevel TRACE = new UCloudLevel(Level.FINEST);
    public static final UCloudLevel FINEST = new UCloudLevel(Level.FINEST);
    public static final UCloudLevel DEBUG = new UCloudLevel(Level.FINER);
    public static final UCloudLevel FINER = new UCloudLevel(Level.FINER);
    public static final UCloudLevel FINE = new UCloudLevel(Level.FINE);
    public static final UCloudLevel CONFIG = new UCloudLevel(Level.CONFIG);
    public static final UCloudLevel INFO = new UCloudLevel(Level.INFO);
    public static final UCloudLevel WARN = new UCloudLevel(Level.WARNING);
    public static final UCloudLevel ERROR = new UCloudLevel(Level.SEVERE);
    public static final UCloudLevel SEVERE = new UCloudLevel(Level.SEVERE);
    public static final UCloudLevel FATAL = new UCloudLevel(Level.SEVERE);
    public static final UCloudLevel OFF = new UCloudLevel(Level.OFF);
    
    private static Map<String, UCloudLevel> stringLevelMapper = new HashMap<String, UCloudLevel>();
    static {
        stringLevelMapper.put("ALL", UCloudLevel.ALL);
        stringLevelMapper.put("TRACE", TRACE);
        stringLevelMapper.put("FINEST", FINEST);
        stringLevelMapper.put("DEBUG", DEBUG);
        stringLevelMapper.put("FINER", FINER);
        stringLevelMapper.put("FINE", FINE);
        stringLevelMapper.put("CONFIG", CONFIG);
        stringLevelMapper.put("INFO", INFO);
        stringLevelMapper.put("WARN", WARN);
        stringLevelMapper.put("ERROR", ERROR);
        stringLevelMapper.put("SEVERE", SEVERE);
        stringLevelMapper.put("FATAL", FATAL);
        stringLevelMapper.put("OFF", OFF);
    }

    private final Level level;
    private final String name;

    public UCloudLevel(Level level) {
    	this.level = level;
        this.name = level.getName();
    }

    public String getName() {
        return name;
    }
    
    public int intValue() {
    	return level.intValue();
    }
    
    public static UCloudLevel getLevel(String levelName) {
    	return stringLevelMapper.get(levelName.toUpperCase());
    }

	@Override
	public String toString() {
		return name;
	}

    Level getLevel() {
        return level;
    }
    
}