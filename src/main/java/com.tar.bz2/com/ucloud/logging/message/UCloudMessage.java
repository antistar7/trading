package com.ucloud.logging.message;

/**
 * @author : aruseran
 * @version 0.1
 * @since 2010. 12. 7
 */
public interface UCloudMessage {
}
