package com.ucloud.logging.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PathNameAnalyzer {
	private static Pattern PAT = Pattern.compile("[$](\\w+|\\{[A-Za-z0-9.-]+\\})");
	/**
	 * $VAR 혹은 ${VAR} 형태의 값을 시스템 프로퍼티나 환경변수 값으로 대치해서 반환한다.
	 * @param original
	 * @return
	 */
	public static String parsePathName(String original) {
		StringBuffer buf = new StringBuffer();
		int cursor = 0;
		Matcher mat = PAT.matcher(original);
		while( mat.find() == true ) {
			buf.append(original.substring(cursor, mat.start()));
			// 매칭의 1번 그룹이 변수명이다. {로 시작하는 것은 좌우의 {} 를 벗긴다.
			String varname = mat.group(1);
			if( varname.startsWith("{") )
				varname = varname.substring(1,varname.length()-1);
			
			String value = getVariableValue(varname);
			if(value != null)
				buf.append(value);
			else
				buf.append(original.substring(mat.start(), mat.end()));
			cursor = mat.end();
		}
		buf.append(original.substring(cursor));
		return buf.toString();
	}
	
	private static String getVariableValue(String varname) {
		String varValue = System.getProperty(varname);
		if( varValue == null )
			varValue = System.getenv(varname);
		return varValue;
	}
	
}
