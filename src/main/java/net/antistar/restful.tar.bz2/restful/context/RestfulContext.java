package com.ucloud.common.restful.context;

import com.ucloud.exception.UCloudException;

import javax.servlet.ServletConfig;

/**
 * Created by IntelliJ IDEA.
 * User: syfer
 * Date: 12. 2. 24.
 * Time: 오후 1:36
 * To change this template use File | Settings | File Templates.
 */
public interface RestfulContext {
    public void destroy() throws UCloudException;
    public void init(ServletConfig config) throws UCloudException;
}
